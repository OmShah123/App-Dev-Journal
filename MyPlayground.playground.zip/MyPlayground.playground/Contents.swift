import UIKit
import Foundation

var greeting = "Hello, playground"

/*
// Data Types

var myVar:String = "hi"
myVar = "bye bye 🤫🧏🏼‍♂️"
print(myVar)

var myInt:Int = 28
myInt += 1
print(myInt)

var cVar = "hi"
print(cVar)

let myConst:String = "Hello"
print(myConst)

/*var a = -21
var b = 5
var c = pow(a, b)
print(c) */
//Didn't work bc Decimal not defined


var a:Double = 2.3
var b:Double = 5.8
var c = floor(a)
var d = ceil(b)
print(c)
print(d)
*/

/*
func calcPay(_ total:Double, _ numPeople:Double = 1) -> String{
    
    var totPrice = total * 1.0833
    var eachPay = totPrice / numPeople
    return("Friends pay $\(eachPay) each")
    
}
print (calcPay(15, 3))
*/
 
 
/*
// Function Declaration
func myFunc (a:Int)->Int {
    //let a  = 10
    let b = 5
    return (a + b)
    
}

//Function Calling
print(myFunc(a:10))
*/

/*
func myFunc (first a:Int, second b:Int = 0)->Int {

    return (a + b)
    

}

//Function Calling
//print(myFunc(a:20))
//print(myFunc(a:10, b:5))

print(myFunc(first: 20))
print(myFunc(first: 20, second: 5))
*/
 
//Argument Labels:

/*
func myFunc (_ a:Int, _ b:Int = 0)->Int {
    
    return (a + b)
    
}
print(myFunc(20))
print(myFunc(20, 5))
*/




struct DatabaseManager {
    //function to save data and return true if successful
    func saveData (data: String) -> Bool{
        //code to save data would go in here
        
        
        return true
    }
    
    
    
}

//Do NOT use camelCase for structures, use HillsCase (omriginal)
struct MyStructure {
    //variables and conditions: PROPERTIES
    var msg:String = "howdy fellas" //Stored Property bc initialized
   
    //Computed Property
    var msgWithPrefix:String {
        return "Om says..." + msg
    }
    
    //UI code: View Code
    
    
    
    //functions: METHODS
    func sendChat(){
        //code to send chat
        print(msg)
        print(msgWithPrefix)
    }
    
    func deleteChat(){
        //code to send chat
        print(msg)
        print(msgWithPrefix)
        
    }
     
    func MyFunction(){
        //print(msg)
        var db:DatabaseManager = DatabaseManager()
        let succ = db.saveData(data: "Hello")
        
        //if else code to handle error in saving data
    }
}

//instance: piece of data that we want to keep track of
var a:MyStructure = MyStructure()
// the datatype of a structure is the name of the structure itself
// you instantiate it by writing the name of the structure followed by ()
a.msg = "Hello"
a.sendChat()

// you can create multiple instances of a structure
var b = MyStructure()
b.msg = "Bye"
b.sendChat()

